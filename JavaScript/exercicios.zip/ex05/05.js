const IIFE = (function(){
    document.write("<h2>Calculadora Universal pronta para uso!</h2>");
})();