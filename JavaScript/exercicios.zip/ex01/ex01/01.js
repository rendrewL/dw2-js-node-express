const name = "Endrew Lemos";
function saudacaoPersonalizada(name) {
  document.write(`<h2>Olá, ${name}! Bem-vindo(a) à Calculadora Universal!</h2>`);
}
saudacaoPersonalizada(name);