const calcularDobro = (n) => {
  return n / 2;
};
document.write(`<h2>A metade de 14234  é: ${calcularDobro(14234)}.</h2>`);